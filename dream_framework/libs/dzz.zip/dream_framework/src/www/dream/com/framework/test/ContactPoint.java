package www.dream.com.framework.test;

import www.dream.com.framework.langPosAnalyzer.HashTarget;

@HashTarget
public class ContactPoint {
	@HashTarget
	private String info;

	public void setInfo(String info) {
		this.info = info;
	}
}
